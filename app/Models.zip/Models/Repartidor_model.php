<?php
namespace App\Models;

use CodeIgniter\Model;

class Repartidor_model extends Model
{
    protected $table      = 'repartidor';          // Nombre de la tabla en BD
    protected $primaryKey = 'id_repartidor';       // Llave primaria
    protected $allowedFields = ['nombre','ap_p','ap_m','tel','direccion','notas']; // Campos permitidos

    // Obtener un producto por su ID
    public function reparRepetido($nombre,$ap){
        return $this->where('nombre', $nombre)->where('ap_p',$ap)->findAll();
    }

    public function getRepart($idrepart)
    {
        return $this->where('id_repartidor', $idrepart)->first();
    }
}
