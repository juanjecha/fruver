<?php
namespace App\Models;

use CodeIgniter\Model;

class Cliente_model extends Model{
    protected $table = 'cliente'; //creación de la tabla 
    protected $primaryKey = 'id_cliente'; //definir llave primaria
    protected $allowedFields = ['nombre','ap_p','ap_m','tel']; //campos de la tabla

    public function ClienteRepetido($nombre,$ap){
        return $this->where('nombre', $nombre)->where('ap_p',$ap)->findAll();
    }

    public function getCliente($idcliente)
    {
        return $this->where('id_cliente', $idcliente)->first();
    }

    public function busquedaCompleja($filtros) {
    if (!empty($filtros['q'])) {
        $this->groupStart()
             ->like('nombre', $filtros['q'])
             ->orLike('ap_p', $filtros['q'])
             ->orLike('ap_m', $filtros['q'])
             ->orLike('tel', $filtros['q'])
             ->groupEnd();
    }

    return $this; 
}
}