<?php
namespace App\Models;

use CodeIgniter\Model;

class Producto_model extends Model
{
    protected $table      = 'producto';          // Nombre de la tabla en BD
    protected $primaryKey = 'id_producto';       // Llave primaria
    protected $allowedFields = ['nombre', 'categoria','descripcion']; // Campos permitidos

    // Obtener un producto por su ID
    public function getProducto($idproducto)
    {
        return $this->where('id_producto', $idproducto)->first();
    }

    // Buscar productos por nombre (para evitar duplicados)
    public function buscaNombre($nombre)
    {
        return $this->where('nombre', $nombre)->findAll();
    }

    // Eliminar producto por ID
    public function eliminarProducto($id)
    {
        return $this->delete($id);
    }


    //BUSQUEDA
    public function busquedaCompleja($filtros)
{
    $builder = $this->builder();

    if (!empty($filtros['q'])) {
        $builder->groupStart()
            ->like('nombre',        $filtros['q'])
            ->orLike('categoria',   $filtros['q'])
            ->orLike('descripcion', $filtros['q'])
        ->groupEnd();
    }

    return $this;
}



public function tieneEntradas($idproducto)
{
    $productos = $this->db->table('productos')
    ->select('producto*, COUNT(entrada.id_entrada) as total_entradas')
    ->join('entrada', 'entrada.id_producto2 = producto.id_producto', 'left')
    ->groupBy('producto.id_producto')
    ->get()
    ->getResultArray();
}
  
   
}
