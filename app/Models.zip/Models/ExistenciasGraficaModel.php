<?php

namespace App\Models;

use CodeIgniter\Model;

class ExistenciasGraficaModel extends Model
{
    protected $table = 'existencias';
    protected $primaryKey = 'id_existencias';
    protected $allowedFields = ['e_total_dia', 'e_bloqueadas', 'e_venta', 'fecha', 'id_producto'];

    // Suma de e_venta, e_bloqueadas por fecha (todos los productos)
    public function getResumenPorFecha()
    {
        return $this->db->table('existencias')
            ->select('
                fecha,
                SUM(e_venta)      AS total_venta,
                SUM(e_bloqueadas) AS total_bloqueadas,
                SUM(e_total_dia)  AS total_dia
            ')
            ->groupBy('fecha')
            ->orderBy('fecha', 'ASC')
            ->get()
            ->getResultArray();
    }

    // Suma de merma por fecha (une merma -> entrada -> existencias por producto y fecha)
    public function getMermaPorFecha()
    {
        return $this->db->table('merma')
            ->select('merma.fecha, SUM(merma.cantidad) AS total_merma')
            ->join('entrada', 'entrada.id_entrada = merma.id_entrada')
            ->groupBy('merma.fecha')
            ->orderBy('merma.fecha', 'ASC')
            ->get()
            ->getResultArray();
    }

    /*public function obtenerMonitoreo() {
        return $this->db->table('producto')
            ->select('producto.nombre, producto.categoria, existencias.e_total_dia, existencias.e_bloqueadas, existencias.e_venta, existencias.fecha')
            ->join('existencias', 'producto.id_producto = existencias.id_producto', 'left')
            ->orderBy('existencias.fecha', 'DESC')
            ->get()->getResultArray();
    }*/

    public function getExistenciasPorProducto():array
    {
        return $this->db->table('existencias')
            ->select('
                producto.id_producto,
                producto.nombre,
                COALESCE(SUM(existencias.e_total_dia), 0)  AS total,
                COALESCE(SUM(existencias.e_bloqueadas), 0)  AS bloqueadas,
                COALESCE(SUM(existencias.e_venta), 0)        AS para_venta
            ')
            ->join('producto', 'producto.id_producto = existencias.id_producto', 'left')
            ->groupBy('producto.id_producto, producto.nombre')
            ->orderBy('producto.nombre', 'ASC')
            ->get()
            ->getResultArray();
    }

    public function getResumen():array
    {
        $productos = $this->getExistenciasPorProducto();

        $total      = count($productos);
        $sin_stock  = 0;
        $stock_bajo = 0;

        foreach ($productos as $p) {
            if ($p['para_venta'] <= 0) {
                $sin_stock++;
            } elseif ($p['para_venta'] < 5) { 
                $stock_bajo++;
            }
        }

        return [
            'total_productos' => $total,
            'sin_stock'       => $sin_stock,
            'stock_bajo'      => $stock_bajo,
            'productos'       => $productos,
        ];
    }


}