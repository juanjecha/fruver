<?php
namespace App\Models;

use CodeIgniter\Model;

class EntradaModel extends Model
{
    protected $table      = 'entrada';          // Nombre de la tabla en BD
    protected $primaryKey = 'id_entrada';       // Llave primaria
    protected $allowedFields = ['fecha','fecha_caducidad', 'u_compra','u_venta','precio_compra','id_producto2','equivalente','conversion','cantidad_vendida']; // Campos permitidos

    public function getEntradasConProducto()
    {
        return $this->db->table('entrada')
            ->select('entrada.id_entrada, entrada.fecha, entrada.cantidad, entrada.u_venta, producto.nombre')
            ->join('producto', 'producto.id_producto = entrada.id_producto2')
            ->get()
            ->getResultArray();
    }
  
   
}
